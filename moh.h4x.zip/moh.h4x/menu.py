from art import *

# Create an ASCII art logo for "moh.h4x"
logo = text2art("moh.h4x")

print(logo)

import socket

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

import subprocess

while True:
    print(GREEN + "Choose an option:" + RESET)
    print(RED + "1. IP Extraction Tool" + RESET)
    print(RED + "2. Port Scanning Tool" + RESET)
    print(RED +"3. Encryption Tool" + RESET)
    print(RED +"4. Quit" + RESET)
    option = input()

    if option == '1':
        # تشغيل أداة استخراج عناوين IP عند الضغط على 1
        subprocess.run(['python', '/data/data/com.termux/files/home/moh.h4x/data/ip.py'])  # استبدل 'ip_extraction_tool.py' بملف الأداة الفعلية
    elif option == '2':
        # تشغيل أداة فحص البورتات عند الضغط على 2
        subprocess.run(['python', '/data/data/com.termux/files/home/moh.h4x/data/port.py'])  # استبدل 'port_scanning_tool.py' بملف الأداة الفعلية
    elif option == '3':
        # تشغيل أداة التشفير عند الضغط على 3
        subprocess.run(['python', '/data/data/com.termux/files/home/moh.h4x/data/crypt.py'])  # استبدل 'encryption_tool.py' بملف الأداة الفعلية
    elif option == '4':
          print(GREEN + "Thanks for using" + RESET)
          break
