from art import *

# Create an ASCII art logo for "moh.h4x"
logo = text2art("moh.h4x")

print(logo)

import socket

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

def get_ip_address(domain):
    try:
        ip_address = socket.gethostbyname(domain)
        return ip_address
    except socket.gaierror:
        return RED + "Unable to resolve host" + RESET

if __name__ == "__main__":
    domain = input(GREEN + "Enter the Website: " + RESET)
    ip = get_ip_address(domain)
    print(GREEN + f"Ip of  {domain} is  {ip}" + RESET)
