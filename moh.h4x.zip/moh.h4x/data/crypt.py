from art import *

# Create an ASCII art logo for "moh.h4x"
logo = text2art("moh.h4x")

print(logo)

import socket

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"


import base64

def encrypt_text(text):
    encrypted_text = base64.b64encode(text.encode()).decode()
    return encrypted_text

def decrypt_text(encrypted_text):
    decoded_text = base64.b64decode(encrypted_text).decode()
    return decoded_text

while True:
    print(GREEN + "Choose an option:" + RESET)
    print(GREEN + "1. Encrypt text" + RESET)
    print(RED + "2. Decrypt text" + RESET)
    print(RED + "3. Quit" + RESET )
    option = input()

    if option == '1':
        text = input(GREEN + "Enter the text to encrypt: " + RESET)
        encrypted_text = encrypt_text(text)
        print(GREEN +"Encrypted text: " + encrypted_text + RESET)
    elif option == '2':
        encrypted_text = input(RED + "Enter the encrypted text: " + RESET)
        decrypted_text = decrypt_text(encrypted_text)
        print(RED + "Decrypted text: " + decrypted_text + RESET)
    elif option == '3':
        break
