from art import *

# Create an ASCII art logo for "moh.h4x"
logo = text2art("moh.h4x")

print(logo)

import socket

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
RESET = "\033[0m"

def scan_port(host, port):
    try:
        # Create a socket object
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Set a timeout for the connection attempt
        sock.settimeout(1)
        # Try to connect to the host and port
        result = sock.connect_ex((host, port))
        if result == 0:
            print(GREEN + f"Port {port} is open" + RESET)
        else:
            print(RED + f"Port {port} is closed" + RESET)
        sock.close()
    except socket.error:
        print(RED + f"Could not connect to {host}" + RESET)

if __name__ == "__main__":
    host = input(GREEN + "Enter the host or IP address: " + RESET)
    # Input the range of ports to scan
    start_port = int(input(GREEN + "Enter the starting port: " + RESET))
    end_port = int(input(GREEN + "Enter the ending port: " + RESET))

    for port in range(start_port, end_port + 1):
        scan_port(host, port)
